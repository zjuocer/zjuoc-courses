/****************************************************************************
* Copyright (C), 2013 �ܶ�Ƕ��ʽ������ www.ourstm.net
*
* �������� �ܶ���STM32������V3.1,V5�ϵ���ͨ��
* QQ: 9191274, ������sun68, Email: sun68@163.com
* �Ա����̣�ourstm.taobao.com
*
* �ļ���: main.c
* ���ݼ���: ��������LED��ת + ��������л���ͬ��ˮ��ģʽ
*
* LED1-LED3 ---V6����V8
* V6----- PB5-LED1
* V7----- PD6-LED2
* V8----- PD3-LED3
*****************************************************************************/

#include "stm32f10x.h"
#include "stm32f10x_exti.h"
#include "stm32f10x_rcc.h"
#include "misc.h"

/* ----------------- ����ȫ�ֱ��� ----------------- */
volatile uint32_t msTicks = 0;        // 1ms ��������SysTick�ṩ��
uint8_t flow_mode = 0;                // ��ˮ��ģʽ 0~3
static uint8_t step = 0;              // ��ˮ�Ƶ�ǰ����
uint32_t last_tick = 0;               // �ϴ��л�ʱ��
/* ------------------------------------------------ */

unsigned char _it0=0,num=0;

void RCC_Configuration(void);
void GPIO_Configuration(void);
void NVIC_Configuration(void);
void Delay(__IO uint32_t nCount);
void numm(void);

int main(void)
{
    unsigned char a=0,b=0,c=0;

    SystemInit();
    SysTick_Config(SystemCoreClock / 1000);   // 1ms tick

    RCC_Configuration();
    NVIC_Configuration();
    GPIO_Configuration();

    while (1)
    {
        /* ==================== ?????? ==================== */
        if(msTicks - last_tick >= 300)           // 300ms ????
        {
            last_tick = msTicks;

            // ???
            GPIO_SetBits(GPIOB, GPIO_Pin_5);
            GPIO_SetBits(GPIOD, GPIO_Pin_6 | GPIO_Pin_3);

            if(flow_mode == 1)                     // ??:1?2?3
            {
                if     (step==0) GPIO_ResetBits(GPIOB, GPIO_Pin_5);
                else if(step==1) GPIO_ResetBits(GPIOD, GPIO_Pin_6);
                else if(step==2) GPIO_ResetBits(GPIOD, GPIO_Pin_3);
                step = (step + 1) % 3;
            }
            else if(flow_mode == 2)                // ??:3?2?1
            {
                if     (step==0) GPIO_ResetBits(GPIOD, GPIO_Pin_3);
                else if(step==1) GPIO_ResetBits(GPIOD, GPIO_Pin_6);
                else if(step==2) GPIO_ResetBits(GPIOB, GPIO_Pin_5);
                step = (step + 1) % 3;
            }
            else if(flow_mode == 3)                // ??:1+3 ? 2
            {
                if(step==0)
                {
                    GPIO_ResetBits(GPIOB, GPIO_Pin_5);
                    GPIO_ResetBits(GPIOD, GPIO_Pin_3);
                }
                else
                {
                    GPIO_ResetBits(GPIOD, GPIO_Pin_6);
                }
                step = (step + 1) % 2;
            }
            // flow_mode == 0 ?????(???????????)
        }

        numm();   // ??????

        /* ???????? */
        if(num==1&&a==0){GPIO_ResetBits(GPIOB, GPIO_Pin_5);a=1;}
        else if(num==1&&a==1){GPIO_SetBits(GPIOB, GPIO_Pin_5);a=0;}
        if(num==2&&b==0){GPIO_ResetBits(GPIOD, GPIO_Pin_6);b=1;}
        else if(num==2&&b==1){GPIO_SetBits(GPIOD, GPIO_Pin_6);b=0;}
        if(num==3&&c==0){GPIO_ResetBits(GPIOD, GPIO_Pin_3);c=1;}
        else if(num==3&&c==1){GPIO_SetBits(GPIOD, GPIO_Pin_3);c=0;}

        /* ==================== ????:????????????? ==================== */
        if(num == 1)           // ?? K1 ? ?????
        {
            flow_mode = 1;
            step = 0;
            last_tick = msTicks;
        }
        else if(num == 2)      // ?? K2 ? ?????
        {
            flow_mode = 2;
            step = 0;
            last_tick = msTicks;
        }
        else if(num == 3)      // ?? K3 ? ?????
        {
            flow_mode = 3;
            step = 0;
            last_tick = msTicks;
        }
        /* ========================================================================= */
    }
}


void numm(void){
   num=0;
   if(_it0==1){
     if(GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_5)==0){
   Delay(0x3ffff);
if(GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_5)==0){
while(GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_5)==0);
num=1;
goto n_exit;
}
  }
   }
   else if(_it0==2){
     if(GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_2)==0){
   Delay(0x3ffff);
if(GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_2)==0){
while(GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_2)==0);
num=2;
goto n_exit;
}
  }
   }
   else if(_it0==3){
     if(GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_3)==0){
   Delay(0x3ffff);
if(GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_3)==0){
while(GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_3)==0);
num=3;
goto n_exit;
}
  }
   }
   n_exit:;
   _it0=0;
}

void Delay(__IO uint32_t nCount)
{
  for(; nCount != 0; nCount--);
}

void RCC_Configuration(void){
  SystemInit();
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO, ENABLE);
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOB | RCC_APB2Periph_GPIOC
   | RCC_APB2Periph_GPIOD| RCC_APB2Periph_GPIOE , ENABLE);
}

void GPIO_Configuration(void)
{
  GPIO_InitTypeDef GPIO_InitStructure;
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(GPIOB, &GPIO_InitStructure);
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6|GPIO_Pin_3;
  GPIO_Init(GPIOD, &GPIO_InitStructure);
  GPIO_SetBits(GPIOB, GPIO_Pin_5);
  GPIO_SetBits(GPIOD, GPIO_Pin_6|GPIO_Pin_3 );

  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
  GPIO_Init(GPIOC, &GPIO_InitStructure);

  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
  GPIO_Init(GPIOC, &GPIO_InitStructure);

  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
  GPIO_Init(GPIOC, &GPIO_InitStructure);

  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
  GPIO_Init(GPIOE, &GPIO_InitStructure);
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  GPIO_Init(GPIOD, &GPIO_InitStructure);
  GPIO_ResetBits(GPIOD, GPIO_Pin_13);
}

void NVIC_Configuration(void)
{
  NVIC_InitTypeDef NVIC_InitStructure;
  EXTI_InitTypeDef EXTI_InitStructure;

  NVIC_PriorityGroupConfig(NVIC_PriorityGroup_1);

  NVIC_InitStructure.NVIC_IRQChannel =EXTI9_5_IRQn;
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
  NVIC_Init(&NVIC_InitStructure);
  NVIC_InitStructure.NVIC_IRQChannel = EXTI2_IRQn;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;
  NVIC_Init(&NVIC_InitStructure);
  NVIC_InitStructure.NVIC_IRQChannel = EXTI3_IRQn;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
  NVIC_Init(&NVIC_InitStructure);

  GPIO_EXTILineConfig(GPIO_PortSourceGPIOC, GPIO_PinSource5);
  GPIO_EXTILineConfig(GPIO_PortSourceGPIOC, GPIO_PinSource2);
  GPIO_EXTILineConfig(GPIO_PortSourceGPIOC, GPIO_PinSource3);

  EXTI_InitStructure.EXTI_Line = EXTI_Line5;
  EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
  EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling;
  EXTI_InitStructure.EXTI_LineCmd = ENABLE;
  EXTI_Init(&EXTI_InitStructure);
  EXTI_InitStructure.EXTI_Line = EXTI_Line2;
  EXTI_Init(&EXTI_InitStructure);
  EXTI_InitStructure.EXTI_Line = EXTI_Line3;
  EXTI_Init(&EXTI_InitStructure);
}

/******************* (C) COPYRIGHT 2013 �ܶ�STM32 *****END OF FILE*****/
