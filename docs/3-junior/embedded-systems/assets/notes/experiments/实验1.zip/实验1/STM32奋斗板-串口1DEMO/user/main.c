/****************************************************************************
* STM32 Minimal Serial Calculator (No prompt strings, pure numbers)
* Input: 32+64*2  -> Output: 160
*****************************************************************************/

#include "stm32f10x.h"
#include "stm32f10x_usart.h"
#include "misc.h"
#include <string.h>
#include <ctype.h>

/* Global variables */
uint8_t RxBuffer[100];
__IO uint8_t RxCounter = 0;
__IO uint8_t RxComplete = 0;

/* Function prototypes */
void RCC_Configuration(void);
void GPIO_Configuration(void);
void NVIC_Configuration(void);
void SendNumber(int num);
int SimpleCalc(char* expr);

int main(void)
{
    USART_InitTypeDef USART_InitStructure;
    int result;

    RCC_Configuration();
    NVIC_Configuration();
    GPIO_Configuration();

    /* USART1 config: 9600 8N1 */
    USART_InitStructure.USART_BaudRate = 9600;
    USART_InitStructure.USART_WordLength = USART_WordLength_8b;
    USART_InitStructure.USART_StopBits = USART_StopBits_1;
    USART_InitStructure.USART_Parity = USART_Parity_No;
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
    USART_Init(USART1, &USART_InitStructure);

    USART_ITConfig(USART1, USART_IT_RXNE, ENABLE);
    USART_Cmd(USART1, ENABLE);

    while (1)
    {
        if (RxComplete)
        {
            RxBuffer[RxCounter] = '\0';
            RxComplete = 0;
            RxCounter = 0;

            /* Remove trailing \r\n */
            if (RxBuffer[strlen((char*)RxBuffer)-1] == '\n')
                RxBuffer[strlen((char*)RxBuffer)-1] = '\0';
            if (RxBuffer[strlen((char*)RxBuffer)-1] == '\r')
                RxBuffer[strlen((char*)RxBuffer)-1] = '\0';

            result = SimpleCalc((char*)RxBuffer);

            if (result != 0x80000000)
                SendNumber(result);      // Only send the number
            else
                SendNumber(-1);          // Error code for invalid or div-by-zero

            /* New line after result */
            while(USART_GetFlagStatus(USART1, USART_FLAG_TC) == RESET);
            USART_SendData(USART1, '\r');
            while(USART_GetFlagStatus(USART1, USART_FLAG_TC) == RESET);
            USART_SendData(USART1, '\n');
        }
    }
}

/* Simple calculator (supports + - * / with precedence) */
int SimpleCalc(char* expr)
{
    int len, i, num = 0, result = 0, temp = 0;
    char op = '+';
    char c;

    len = strlen(expr);
    i = 0;
    while (i < len && expr[i] == ' ') i++;

    while (i <= len)
    {
        c = (i < len) ? expr[i] : '\0';

        if (isdigit(c))
            num = num * 10 + (c - '0');
        else if (c == '*' || c == '/' || c == '+' || c == '-' || c == '\0')
        {
            if (op == '*')      temp = temp * num;
            else if (op == '/')
            {
                if (num == 0) return 0x80000000;
                temp = temp / num;
            }
            else
            {
                result += temp;
                temp = num;
            }

            if (c == '+' || c == '-' || c == '\0')
            {
                result += (op == '-') ? -temp : temp;
                temp = 0;
            }
            op = c;
            num = 0;
        }
        else if (c != ' ')
            return 0x80000000;

        i++;
    }
    return result;
}

/* Send integer as string (no printf) */
void SendNumber(int num)
{
    char buf[12];
    char *p = buf + 11;
    int is_negative = 0;

    if (num == 0)
    {
        USART_SendData(USART1, '0');
        while(USART_GetFlagStatus(USART1, USART_FLAG_TC) == RESET);
        return;
    }

    if (num < 0)
    {
        is_negative = 1;
        num = -num;
    }

    *p = '\0';
    while (num > 0)
    {
        *--p = '0' + (num % 10);
        num /= 10;
    }

    if (is_negative)
        *--p = '-';

    while (*p)
    {
        USART_SendData(USART1, *p++);
        while(USART_GetFlagStatus(USART1, USART_FLAG_TC) == RESET);
    }
}

/* Peripheral configurations */
void RCC_Configuration(void)
{
    SystemInit();
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1 | RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOB | RCC_APB2Periph_AFIO, ENABLE);
}

void GPIO_Configuration(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
}

void NVIC_Configuration(void)
{
    NVIC_InitTypeDef NVIC_InitStructure;

    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_0);
    NVIC_InitStructure.NVIC_IRQChannel = USART1_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
}

/* Place this in stm32f10x_it.c */
#if 0  // Remove this block after copying to stm32f10x_it.c
void USART1_IRQHandler(void)
{
    if (USART_GetITStatus(USART1, USART_IT_RXNE) != RESET)
    {
        uint8_t received = USART_ReceiveData(USART1);

        if (received == '\r' || received == '\n')
        {
            if (RxCounter > 0)
                RxComplete = 1;
        }
        else if (RxCounter < 99)
        {
            RxBuffer[RxCounter++] = received;
        }
    }
}
#endif

/* End of file - empty line */